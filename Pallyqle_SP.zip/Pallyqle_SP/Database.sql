-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: fdb3.awardspace.net
-- Generation Time: Aug 18, 2019 at 01:10 AM
-- Server version: 5.7.20-log
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `2040551_rts`
--

-- --------------------------------------------------------

--
-- Table structure for table `DS_CreationRequest`
--

CREATE TABLE `DS_CreationRequest` (
  `RequestIndex` int(255) NOT NULL,
  `Region` varchar(1000) NOT NULL,
  `MapName` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `DS_CreationRequest`
--

INSERT INTO `DS_CreationRequest` (`RequestIndex`, `Region`, `MapName`) VALUES
(1, 'North America', '');

-- --------------------------------------------------------

--
-- Table structure for table `DS_HostInfo`
--

CREATE TABLE `DS_HostInfo` (
  `Hosts` varchar(1000) NOT NULL,
  `ServerType` varchar(1000) NOT NULL,
  `Name` varchar(1000) NOT NULL,
  `Password` varchar(1000) NOT NULL,
  `Region` varchar(1000) NOT NULL,
  `MNP` int(255) NOT NULL,
  `PG` varchar(1000) NOT NULL,
  `IG` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `DS_LoginRequest`
--

CREATE TABLE `DS_LoginRequest` (
  `RequestIndex` int(255) NOT NULL,
  `Username` varchar(1000) NOT NULL,
  `IP` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `MOBA_HeroList`
--

CREATE TABLE `MOBA_HeroList` (
  `Name` varchar(1000) NOT NULL,
  `IsAvailable` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `MOBA_HeroList`
--

INSERT INTO `MOBA_HeroList` (`Name`, `IsAvailable`) VALUES
('Hero0', 1),
('Hero1', 1),
('Hero2', 1),
('Hero3', 1),
('Hero4', 1),
('Hero5', 1),
('Hero6', 1),
('Hero7', 1),
('Hero8', 1),
('Hero9', 1),
('Hero10', 1),
('Hero11', 1);

-- --------------------------------------------------------

--
-- Table structure for table `Servers`
--

CREATE TABLE `Servers` (
  `ID` int(255) NOT NULL,
  `ServerType` varchar(20) NOT NULL,
  `IP` varchar(20) NOT NULL,
  `Port` int(255) NOT NULL,
  `Name` varchar(1000) NOT NULL,
  `Password` varchar(1000) NOT NULL,
  `Region` varchar(1000) NOT NULL,
  `IsInGame` tinyint(1) NOT NULL,
  `CNP` int(10) NOT NULL,
  `MNP` int(10) NOT NULL,
  `PG` varchar(1000) NOT NULL,
  `IG` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Users_Char`
--

CREATE TABLE `Users_Char` (
  `UserID` int(20) NOT NULL,
  `Server` varchar(1000) NOT NULL,
  `Name` varchar(1000) NOT NULL,
  `Class` varchar(1000) NOT NULL,
  `XP` varchar(1000) NOT NULL,
  `Status` varchar(1000) NOT NULL,
  `Inv` varchar(1000) NOT NULL,
  `Equips` varchar(1000) NOT NULL,
  `Skills` varchar(1000) NOT NULL,
  `Talents` varchar(1000) NOT NULL,
  `Appearance` varchar(1000) NOT NULL,
  `Gameplay` varchar(1000) NOT NULL,
  `Keybinds` varchar(1000) NOT NULL,
  `ChatTab` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Users_Char`
--

INSERT INTO `Users_Char` (`UserID`, `Server`, `Name`, `Class`, `XP`, `Status`, `Inv`, `Equips`, `Skills`, `Talents`, `Appearance`, `Gameplay`, `Keybinds`, `ChatTab`) VALUES
(12, 'Lobby|Official 0', 'Char0', 'None', '1:0.0|1:0.0|', '', '', '', '', '', 'Species0|1.0:0.0:0.0|1.0|', '', '', ''),
(12, 'Lobby|Official 0', 'Char1', 'None', '1:0.0|1:0.0|', '', '', '', '', '', 'Species1|0.0:0.240508:1.0|1.0|', '', '', ''),
(12, 'Lobby|Official 0', 'Char2', 'None', '1:0.0|1:0.0|', '', '', '', '', '', 'Species0|0.197614:1.0:0.0|1.0|', '', '', ''),
(12, 'Lobby|Official 0', 'Char3', 'None', '1:0.0|1:0.0|', '', '', '', '', '', 'Species1|0.0:0.240508:1.0|1.0|', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `Users_Play`
--

CREATE TABLE `Users_Play` (
  `Username` varchar(1000) NOT NULL,
  `IsLogin` tinyint(1) NOT NULL,
  `MainIP` varchar(1000) NOT NULL,
  `InstanceIP` varchar(1000) NOT NULL,
  `PotentialGI` varchar(1000) NOT NULL,
  `Alert` varchar(1000) NOT NULL,
  `CurrentChar` varchar(1000) NOT NULL,
  `CurrentParty` varchar(1000) NOT NULL,
  `Leader` varchar(1000) NOT NULL,
  `XServerMessages` varchar(1000) NOT NULL,
  `GIReady` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Users_Play`
--

INSERT INTO `Users_Play` (`Username`, `IsLogin`, `MainIP`, `InstanceIP`, `PotentialGI`, `Alert`, `CurrentChar`, `CurrentParty`, `Leader`, `XServerMessages`, `GIReady`) VALUES
('pallyqle', 0, '', '', '', '', '', '', '', '', ''),
('Gerok', 0, '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `Users_Save`
--

CREATE TABLE `Users_Save` (
  `UserID` int(20) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Email` varchar(1000) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `PrevIP` varchar(1000) NOT NULL,
  `Verification` varchar(1000) NOT NULL,
  `PrevLogin` varchar(1000) NOT NULL,
  `FavServers` varchar(1000) NOT NULL,
  `CharLimit` int(255) NOT NULL,
  `FriendList` varchar(1000) NOT NULL,
  `BlockedList` varchar(1000) NOT NULL,
  `BankInv` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Users_Save`
--

INSERT INTO `Users_Save` (`UserID`, `Username`, `Email`, `Password`, `PrevIP`, `Verification`, `PrevLogin`, `FavServers`, `CharLimit`, `FriendList`, `BlockedList`, `BankInv`) VALUES
(12, 'pallyqle', 'a@.com', 'a', '', '', '2019|8|17|18|6|53', '', 4, '', '', ''),
(13, 'Gerok', 'a@.com', 'a', '', '', '2019|8|15|15|8|14', '', 4, '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `DS_CreationRequest`
--
ALTER TABLE `DS_CreationRequest`
  ADD PRIMARY KEY (`RequestIndex`);

--
-- Indexes for table `DS_HostInfo`
--
ALTER TABLE `DS_HostInfo`
  ADD PRIMARY KEY (`Hosts`);

--
-- Indexes for table `DS_LoginRequest`
--
ALTER TABLE `DS_LoginRequest`
  ADD PRIMARY KEY (`RequestIndex`);

--
-- Indexes for table `MOBA_HeroList`
--
ALTER TABLE `MOBA_HeroList`
  ADD PRIMARY KEY (`Name`);

--
-- Indexes for table `Servers`
--
ALTER TABLE `Servers`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Users_Char`
--
ALTER TABLE `Users_Char`
  ADD PRIMARY KEY (`Name`);

--
-- Indexes for table `Users_Play`
--
ALTER TABLE `Users_Play`
  ADD PRIMARY KEY (`Username`);

--
-- Indexes for table `Users_Save`
--
ALTER TABLE `Users_Save`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `DS_CreationRequest`
--
ALTER TABLE `DS_CreationRequest`
  MODIFY `RequestIndex` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `DS_LoginRequest`
--
ALTER TABLE `DS_LoginRequest`
  MODIFY `RequestIndex` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Servers`
--
ALTER TABLE `Servers`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `Users_Save`
--
ALTER TABLE `Users_Save`
  MODIFY `UserID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
