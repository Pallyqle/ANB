﻿namespace DSManager
{
    partial class DS_RegionManager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.ETB_Return = new System.Windows.Forms.TextBox();
            this.ETB_LobbyPath = new System.Windows.Forms.TextBox();
            this.T_SetPath = new System.Windows.Forms.Label();
            this.T_LobbyPath = new System.Windows.Forms.Label();
            this.T_RPGPath = new System.Windows.Forms.Label();
            this.ETB_RPGPath = new System.Windows.Forms.TextBox();
            this.T_PGPath = new System.Windows.Forms.Label();
            this.ETB_PGPath = new System.Windows.Forms.TextBox();
            this.T_SetServerInfo = new System.Windows.Forms.Label();
            this.CB_ServerType = new System.Windows.Forms.ComboBox();
            this.T_ServerType = new System.Windows.Forms.Label();
            this.CB_Region = new System.Windows.Forms.ComboBox();
            this.T_Region = new System.Windows.Forms.Label();
            this.T_ServerName = new System.Windows.Forms.Label();
            this.ETB_ServerName = new System.Windows.Forms.TextBox();
            this.T_MNP = new System.Windows.Forms.Label();
            this.B_CreateServer = new System.Windows.Forms.Button();
            this.B_StartDS = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.T_DSRegion = new System.Windows.Forms.Label();
            this.CB_DSRegion = new System.Windows.Forms.ComboBox();
            this.B_ResetDatabase = new System.Windows.Forms.Button();
            this.T_PathExtension = new System.Windows.Forms.Label();
            this.CB_PathExtension = new System.Windows.Forms.ComboBox();
            this.Num_MNP = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.Num_MNP)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 3000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // ETB_Return
            // 
            this.ETB_Return.Location = new System.Drawing.Point(51, 675);
            this.ETB_Return.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.ETB_Return.Name = "ETB_Return";
            this.ETB_Return.ReadOnly = true;
            this.ETB_Return.Size = new System.Drawing.Size(444, 44);
            this.ETB_Return.TabIndex = 9999;
            this.ETB_Return.TabStop = false;
            // 
            // ETB_LobbyPath
            // 
            this.ETB_LobbyPath.Location = new System.Drawing.Point(181, 111);
            this.ETB_LobbyPath.Name = "ETB_LobbyPath";
            this.ETB_LobbyPath.Size = new System.Drawing.Size(381, 44);
            this.ETB_LobbyPath.TabIndex = 0;
            // 
            // T_SetPath
            // 
            this.T_SetPath.AutoSize = true;
            this.T_SetPath.Location = new System.Drawing.Point(51, 51);
            this.T_SetPath.Name = "T_SetPath";
            this.T_SetPath.Size = new System.Drawing.Size(192, 37);
            this.T_SetPath.TabIndex = 2;
            this.T_SetPath.Text = "Set DS Path";
            // 
            // T_LobbyPath
            // 
            this.T_LobbyPath.AutoSize = true;
            this.T_LobbyPath.Location = new System.Drawing.Point(51, 120);
            this.T_LobbyPath.Name = "T_LobbyPath";
            this.T_LobbyPath.Size = new System.Drawing.Size(104, 37);
            this.T_LobbyPath.TabIndex = 3;
            this.T_LobbyPath.Text = "Lobby";
            // 
            // T_RPGPath
            // 
            this.T_RPGPath.AutoSize = true;
            this.T_RPGPath.Location = new System.Drawing.Point(51, 188);
            this.T_RPGPath.Name = "T_RPGPath";
            this.T_RPGPath.Size = new System.Drawing.Size(85, 37);
            this.T_RPGPath.TabIndex = 6;
            this.T_RPGPath.Text = "RPG";
            // 
            // ETB_RPGPath
            // 
            this.ETB_RPGPath.Location = new System.Drawing.Point(181, 179);
            this.ETB_RPGPath.Name = "ETB_RPGPath";
            this.ETB_RPGPath.Size = new System.Drawing.Size(381, 44);
            this.ETB_RPGPath.TabIndex = 1;
            // 
            // T_PGPath
            // 
            this.T_PGPath.AutoSize = true;
            this.T_PGPath.Location = new System.Drawing.Point(51, 256);
            this.T_PGPath.Name = "T_PGPath";
            this.T_PGPath.Size = new System.Drawing.Size(63, 37);
            this.T_PGPath.TabIndex = 9;
            this.T_PGPath.Text = "PG";
            // 
            // ETB_PGPath
            // 
            this.ETB_PGPath.Location = new System.Drawing.Point(181, 248);
            this.ETB_PGPath.Name = "ETB_PGPath";
            this.ETB_PGPath.Size = new System.Drawing.Size(381, 44);
            this.ETB_PGPath.TabIndex = 2;
            // 
            // T_SetServerInfo
            // 
            this.T_SetServerInfo.AutoSize = true;
            this.T_SetServerInfo.Location = new System.Drawing.Point(51, 324);
            this.T_SetServerInfo.Name = "T_SetServerInfo";
            this.T_SetServerInfo.Size = new System.Drawing.Size(227, 37);
            this.T_SetServerInfo.TabIndex = 11;
            this.T_SetServerInfo.Text = "Set Server Info";
            // 
            // CB_ServerType
            // 
            this.CB_ServerType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CB_ServerType.FormattingEnabled = true;
            this.CB_ServerType.Items.AddRange(new object[] {
            "Lobby",
            "RPG"});
            this.CB_ServerType.Location = new System.Drawing.Point(181, 384);
            this.CB_ServerType.Name = "CB_ServerType";
            this.CB_ServerType.Size = new System.Drawing.Size(321, 45);
            this.CB_ServerType.TabIndex = 5;
            // 
            // T_ServerType
            // 
            this.T_ServerType.AutoSize = true;
            this.T_ServerType.Location = new System.Drawing.Point(51, 393);
            this.T_ServerType.Name = "T_ServerType";
            this.T_ServerType.Size = new System.Drawing.Size(87, 37);
            this.T_ServerType.TabIndex = 13;
            this.T_ServerType.Text = "Type";
            // 
            // CB_Region
            // 
            this.CB_Region.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CB_Region.FormattingEnabled = true;
            this.CB_Region.Items.AddRange(new object[] {
            "North America",
            "South America",
            "Western Europe",
            "Eastern Europe",
            "Middle East",
            "Africa",
            "Asia",
            "South East Asia",
            "Antarctica"});
            this.CB_Region.Location = new System.Drawing.Point(181, 453);
            this.CB_Region.Name = "CB_Region";
            this.CB_Region.Size = new System.Drawing.Size(321, 45);
            this.CB_Region.TabIndex = 6;
            // 
            // T_Region
            // 
            this.T_Region.AutoSize = true;
            this.T_Region.Location = new System.Drawing.Point(51, 461);
            this.T_Region.Name = "T_Region";
            this.T_Region.Size = new System.Drawing.Size(117, 37);
            this.T_Region.TabIndex = 15;
            this.T_Region.Text = "Region";
            // 
            // T_ServerName
            // 
            this.T_ServerName.AutoSize = true;
            this.T_ServerName.Location = new System.Drawing.Point(542, 393);
            this.T_ServerName.Name = "T_ServerName";
            this.T_ServerName.Size = new System.Drawing.Size(103, 37);
            this.T_ServerName.TabIndex = 17;
            this.T_ServerName.Text = "Name";
            // 
            // ETB_ServerName
            // 
            this.ETB_ServerName.Location = new System.Drawing.Point(659, 384);
            this.ETB_ServerName.Name = "ETB_ServerName";
            this.ETB_ServerName.Size = new System.Drawing.Size(321, 44);
            this.ETB_ServerName.TabIndex = 7;
            // 
            // T_MNP
            // 
            this.T_MNP.AutoSize = true;
            this.T_MNP.Location = new System.Drawing.Point(542, 461);
            this.T_MNP.Name = "T_MNP";
            this.T_MNP.Size = new System.Drawing.Size(88, 37);
            this.T_MNP.TabIndex = 20;
            this.T_MNP.Text = "MNP";
            // 
            // B_CreateServer
            // 
            this.B_CreateServer.Location = new System.Drawing.Point(51, 561);
            this.B_CreateServer.Name = "B_CreateServer";
            this.B_CreateServer.Size = new System.Drawing.Size(279, 80);
            this.B_CreateServer.TabIndex = 9;
            this.B_CreateServer.Text = "Create Server";
            this.B_CreateServer.UseVisualStyleBackColor = true;
            this.B_CreateServer.Click += new System.EventHandler(this.B_CreateServer_Click);
            // 
            // B_StartDS
            // 
            this.B_StartDS.Location = new System.Drawing.Point(374, 561);
            this.B_StartDS.Name = "B_StartDS";
            this.B_StartDS.Size = new System.Drawing.Size(279, 80);
            this.B_StartDS.TabIndex = 10;
            this.B_StartDS.Text = "Start";
            this.B_StartDS.UseVisualStyleBackColor = true;
            this.B_StartDS.Click += new System.EventHandler(this.B_StartDS_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(51, 740);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 37);
            this.label1.TabIndex = 22;
            this.label1.Text = "   ";
            // 
            // T_DSRegion
            // 
            this.T_DSRegion.AutoSize = true;
            this.T_DSRegion.Location = new System.Drawing.Point(602, 188);
            this.T_DSRegion.Name = "T_DSRegion";
            this.T_DSRegion.Size = new System.Drawing.Size(170, 37);
            this.T_DSRegion.TabIndex = 10000;
            this.T_DSRegion.Text = "DS Region";
            // 
            // CB_DSRegion
            // 
            this.CB_DSRegion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CB_DSRegion.FormattingEnabled = true;
            this.CB_DSRegion.Items.AddRange(new object[] {
            "North America",
            "South America",
            "Western Europe",
            "Eastern Europe",
            "Middle East",
            "Africa",
            "Asia",
            "South East Asia",
            "Antarctica"});
            this.CB_DSRegion.Location = new System.Drawing.Point(602, 248);
            this.CB_DSRegion.Name = "CB_DSRegion";
            this.CB_DSRegion.Size = new System.Drawing.Size(321, 45);
            this.CB_DSRegion.TabIndex = 4;
            // 
            // B_ResetDatabase
            // 
            this.B_ResetDatabase.Location = new System.Drawing.Point(700, 561);
            this.B_ResetDatabase.Name = "B_ResetDatabase";
            this.B_ResetDatabase.Size = new System.Drawing.Size(279, 80);
            this.B_ResetDatabase.TabIndex = 11;
            this.B_ResetDatabase.Text = "Clear Servers";
            this.B_ResetDatabase.UseVisualStyleBackColor = true;
            this.B_ResetDatabase.Click += new System.EventHandler(this.B_ResetDatabase_Click);
            // 
            // T_PathExtension
            // 
            this.T_PathExtension.AutoSize = true;
            this.T_PathExtension.Location = new System.Drawing.Point(602, 51);
            this.T_PathExtension.Name = "T_PathExtension";
            this.T_PathExtension.Size = new System.Drawing.Size(231, 37);
            this.T_PathExtension.TabIndex = 10004;
            this.T_PathExtension.Text = "Path Extension";
            // 
            // CB_PathExtension
            // 
            this.CB_PathExtension.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CB_PathExtension.FormattingEnabled = true;
            this.CB_PathExtension.Items.AddRange(new object[] {
            ".lnk",
            ".exe"});
            this.CB_PathExtension.Location = new System.Drawing.Point(602, 111);
            this.CB_PathExtension.Name = "CB_PathExtension";
            this.CB_PathExtension.Size = new System.Drawing.Size(321, 45);
            this.CB_PathExtension.TabIndex = 3;
            // 
            // Num_MNP
            // 
            this.Num_MNP.Location = new System.Drawing.Point(659, 454);
            this.Num_MNP.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.Num_MNP.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.Num_MNP.Name = "Num_MNP";
            this.Num_MNP.Size = new System.Drawing.Size(120, 44);
            this.Num_MNP.TabIndex = 8;
            this.Num_MNP.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // DS_RegionManager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 37F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1102, 771);
            this.Controls.Add(this.Num_MNP);
            this.Controls.Add(this.CB_PathExtension);
            this.Controls.Add(this.T_PathExtension);
            this.Controls.Add(this.B_ResetDatabase);
            this.Controls.Add(this.CB_DSRegion);
            this.Controls.Add(this.T_DSRegion);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.B_StartDS);
            this.Controls.Add(this.T_MNP);
            this.Controls.Add(this.T_ServerName);
            this.Controls.Add(this.ETB_ServerName);
            this.Controls.Add(this.T_Region);
            this.Controls.Add(this.CB_Region);
            this.Controls.Add(this.T_ServerType);
            this.Controls.Add(this.CB_ServerType);
            this.Controls.Add(this.T_SetServerInfo);
            this.Controls.Add(this.B_CreateServer);
            this.Controls.Add(this.T_PGPath);
            this.Controls.Add(this.ETB_PGPath);
            this.Controls.Add(this.T_RPGPath);
            this.Controls.Add(this.ETB_RPGPath);
            this.Controls.Add(this.T_LobbyPath);
            this.Controls.Add(this.T_SetPath);
            this.Controls.Add(this.ETB_LobbyPath);
            this.Controls.Add(this.ETB_Return);
            this.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.Name = "DS_RegionManager";
            this.Text = "DS Region Manager";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.DSManager_FormClosed);
            this.Load += new System.EventHandler(this.DSManager_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Num_MNP)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox ETB_Return;
        private System.Windows.Forms.TextBox ETB_LobbyPath;
        private System.Windows.Forms.Label T_SetPath;
        private System.Windows.Forms.Label T_LobbyPath;
        private System.Windows.Forms.Label T_RPGPath;
        private System.Windows.Forms.TextBox ETB_RPGPath;
        private System.Windows.Forms.Label T_PGPath;
        private System.Windows.Forms.TextBox ETB_PGPath;
        private System.Windows.Forms.Label T_SetServerInfo;
        private System.Windows.Forms.ComboBox CB_ServerType;
        private System.Windows.Forms.Label T_ServerType;
        private System.Windows.Forms.ComboBox CB_Region;
        private System.Windows.Forms.Label T_Region;
        private System.Windows.Forms.Label T_ServerName;
        private System.Windows.Forms.TextBox ETB_ServerName;
        private System.Windows.Forms.Label T_MNP;
        private System.Windows.Forms.Button B_CreateServer;
        private System.Windows.Forms.Button B_StartDS;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label T_DSRegion;
        private System.Windows.Forms.ComboBox CB_DSRegion;
        private System.Windows.Forms.Button B_ResetDatabase;
        private System.Windows.Forms.Label T_PathExtension;
        private System.Windows.Forms.ComboBox CB_PathExtension;
        private System.Windows.Forms.NumericUpDown Num_MNP;
    }
}

