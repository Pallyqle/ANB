<?php

        $Return = "";
        /*$Username = "Pallyqle";
	$Name = "pallyqlee";
	$Class = "Warrior";
	$XP = "Level|1|0~Rank|1|0";
        $Status = "";
        $Inv = "";
	$Equips = "";
	$Skills = "";
        $Appearance = "Species0|1:0:0|1.0|";
        $Gameplay = "";
	$KeyBind = "";
        $ChatTab = "Say|1|1|0|0|~Whisper|1|0|0|1|~Party|1|0|1|0|~";*/
        
        $UserID = $_REQUEST["UserID"];
	$Name = $_REQUEST["Name"];
	$Class = $_REQUEST["Class"];
	$XP = $_REQUEST["XP"];
        $Status = $_REQUEST["Status"];
        $Inv = $_REQUEST["Inv"];
	$Equips = $_REQUEST["Equips"];
	$Skills = $_REQUEST["Skills"];
        $Appearance = $_REQUEST["Appearance"];
	$Gameplay = $_REQUEST["Gameplay"];
        $Keybinds = $_REQUEST["Keybinds"];
        $ChatTab = $_REQUEST["ChatTab"];
	
	$con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");
        if ($con->connect_errno) 
        {
                $Return = "Error0";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "SELECT * FROM Users_Char WHERE `Name` = '".$Name."'";
                $result = mysqli_query($con, $sql);
                if(mysqli_num_rows($result) == 0)
                {
                        $sql = "INSERT INTO Users_Char (UserID, Server, Name, Class, XP, Status, Inv, Equips, Skills, Talents, 
                                        Appearance, Gameplay, Keybinds, ChatTab) 
                                VALUE('$UserID', '', '$Name', '$Class', '$XP', '$Status', '$Inv', 
                                        '$Equips', '$Skills', '', '$Appearance', '$Gameplay', '$Keybinds', '$ChatTab')";
                        mysqli_query($con, $sql);
                        
                        $Return = "Character Created";
                        echo "{Content: \"".$Return."\"}";
                }
                else
                {
                        $Return = "Error6";
                        echo "{Content: \"".$Return."\"}";
                }
        }
			
?>