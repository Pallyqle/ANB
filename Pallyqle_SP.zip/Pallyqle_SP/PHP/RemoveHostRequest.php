<?php

        $Return = "";        
	$Hosts = $_REQUEST["Hosts"];
	
	$con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");
        if ($con->connect_errno) 
        {
                $Return = "Connect Failed";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "DELETE FROM DS_HostInfo WHERE `Hosts` = '".$Hosts."'";
                mysqli_query($con, $sql);  
                
                $Return = "Request Removed";
                echo "{Content: \"".$Return."\"}";
        }
        
?>