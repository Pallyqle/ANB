<?php
        
        $Return = "";
        //$ServerType = "Lobby";
        
	$ServerType = $_REQUEST["ServerType"];
	
	$con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");
        if ($con->connect_errno) 
        {
                $Return = "Error0";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "SELECT * FROM Servers WHERE `ServerType` = '".$ServerType."' AND `Password` != 'Thienhoang1'";
                $result = mysqli_query($con, $sql);
                if(mysqli_num_rows($result) > 0)
                {
                        while($row = mysqli_fetch_assoc($result))
                        {
                                $Return .= $row['ServerType']."/".$row['IP']."/".$row['Port']."/".$row['Name']."/".$row['Password']."/".
                                                $row['Region']."/".$row['IsInGame']."/".$row['CNP']."/".$row['MNP']."/".$row['PG']."/".
                                                $row['IG'].";";
                        }
                        echo "{Content: \"".$Return."\"}";
                }      
                else
                {
                        $Return = "Error12";
                        echo "{Content: \"".$Return."\"}"; 
                }
        }
        
?>