<?php
        
        $Return = "";
        //$ServerType = "GI";
	//$IP = "127.0.0.1";
        //$PortNumber = "7777";
        
        $ServerType = $_REQUEST["ServerType"]; ;
	$IP = $_REQUEST["IP"];
        $Port = $_REQUEST["Port"];  

        $con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");
        if ($con->connect_errno) 
        {
                $Return = "Error0";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "SELECT * FROM Servers WHERE `IP` = '".$IP."' AND `Port` = '".$Port."'";
                $result = mysqli_query($con, $sql);
                if(mysqli_num_rows($result) > 0)
                {
                        $row = mysqli_fetch_assoc($result);
                        $Return = "Server Exist" . "/" . $row['IP'] . "/" . $row['PortNumber'];
                        echo "{Content: \"".$Return."\"}"; 
                }
                else
                {
                        switch($ServerType)
                        {                                    
                                case "GI":
                                        $sql = "INSERT INTO `Servers` (`ID`, `ServerType`, `IP`, `Port`, `Name`, `Password`, `Region`,
                                                `IsInGame`, `CNP`, `MNP`, `PG`, `IG`) 
                                                 VALUES (NULL, '$ServerType', '$IP', '$Port', '', 'Thienhoang1', '', '0', '0', '0', 
                                                 '', '')";
                                        mysqli_query($con, $sql);
                                        break;                        
                                default:
                                        $sql = "INSERT INTO `Servers` (`ID`, `ServerType`, `IP`, `Port`, `Name`, `Password`, `Region`,
                                                `IsInGame`, `CNP`, `MNP`, `PG`, `IG`) 
                                                 VALUES (NULL, '$ServerType', '$IP', '$Port', '', 'Thienhoang1', '', '0', '0', '0', 
                                                 '', '')";
                                        mysqli_query($con, $sql);
                                        break;  
                        }
                        
                        
                        $Return = "Server Created";
                        echo "{Content: \"".$Return."\"}";
                                      
                }        
        }
?>