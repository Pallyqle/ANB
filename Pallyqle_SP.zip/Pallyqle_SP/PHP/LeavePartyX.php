<?php

        $Return = "";
	$Leaver = $_REQUEST["Leaver"];
        $NewLeader = $_REQUEST["NewLeader"];
        $PartyMembers = $_REQUEST["PartyMembers"];

	$con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");
        if ($con->connect_errno) 
        {
                $Return = "Connect Failed";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$Leaver."'";
                $row = mysqli_fetch_assoc(mysqli_query($con, $sql));
                        
                $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$NewLeader."'";
                $row2 = mysqli_fetch_assoc(mysqli_query($con, $sql));
                $NewLeader = $row2['Username'];
        
                $PartyMembersArray = explode("|", $PartyMembers);
                foreach($PartyMembersArray as $x)
                {      
                        $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$x."'";
                        $row3 = mysqli_fetch_assoc(mysqli_query($con, $sql));
                        
                        if((strpos($row3['Alert'], 'Party:Left:'.$row['Username'].":".$row['CurrentChar'].":".$NewLeader.'|') === false))
                        {
                                $sql = "UPDATE `Users_Play` SET `Alert` = '".$row3['Alert']."Party:Left:".$row['Username'].":".$row['CurrentChar'].":"
                                        .$NewLeader."|' 
                                        WHERE `Username` = '".$row3['Username']."'";
                                        
                                mysqli_query($con, $sql);
                        }
                }  
        }
        
?>