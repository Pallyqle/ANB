<?php

        $Return = "";
        $Username = $_REQUEST["Username"]; 
	$IP = $_REQUEST["IP"]; 
        $IsInstance = $_REQUEST["IsInstance"];

        $con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");
        if ($con->connect_errno) 
        {
                $Return = "Error0";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                if($IsInstance == 1)
                {
                        $sql = "UPDATE `Users_Play` SET `InstanceIP` = '".$IP."' WHERE `Username` = '".$Username."'";
                        mysqli_query($con, $sql);
                }
                else
                {
                        $sql = "UPDATE `Users_Play` SET `MainIP` = '".$IP."' WHERE `Username` = '".$Username."'";
                        mysqli_query($con, $sql);
                }   
                
                $Return = $IP;
                echo "{Content: \"".$Return."\"}"; 
        }

?>