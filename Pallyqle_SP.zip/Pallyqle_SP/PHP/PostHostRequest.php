<?php
        
        $Return = "";
        $Hosts = $_REQUEST["Hosts"];
        $Name = $_REQUEST["Name"];
        $Password = $_REQUEST["Password"];
        $Region = $_REQUEST["Region"];
        $MNP = $_REQUEST["MNP"];
        $PG = $_REQUEST["PG"];
        $IG = $_REQUEST["IG"];
        $MapName = $_REQUEST["MapName"];
        	
	$con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");
        if ($con->connect_errno) 
        {
                $Return = "Error0";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "INSERT INTO `DS_HostInfo` (`Hosts`, `Name`, `Password`, `Region`, `MNP`, `PG`, `IG`) 
                        VALUES ('$Hosts', '$Name', '$Password', '$Region', '$MNP', '$PG', '$IG')";
                mysqli_query($con, $sql);
                
                $sql = "INSERT INTO `DS_CreationRequest` (`RequestIndex`, `Region`, `MapName`) VALUES (NULL, '', '$MapName')";
                mysqli_query($con, $sql);
                
                $Return = "Game Posted";
                echo "{Content: \"".$Return."\"}"; 
	}

?>