<?php

        $Return = "";
        //$UserID = "";
	
        $UserID = $_REQUEST["UserID"];
	
	$con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");
        if ($con->connect_errno) 
        {
                $Return = "Error0";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "SELECT * FROM Users_Save WHERE `UserID` = '".$UserID."'";
                $row = mysqli_fetch_assoc(mysqli_query($con, $sql));
                
                $Return = $row['FavServers']."/".$row['CharLimit']."/".$row['FriendList']."/".$row['BlockedList']."/".$row['BankInv'];
                        
                echo "{Content: \"".$Return."\"}"; 
        }
        
?>