<?php
        
        $Return = "";
        $Username = $_REQUEST["Username"];
        $IP = $_REQUEST["IP"];
	
	$con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");
        if ($con->connect_errno) 
        {
                $Return = "Connect Failed";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "INSERT INTO `DS_LoginRequest` (`RequestIndex`, `Username`, `IP`) VALUES (NULL, '$Username', '$IP')";
                mysqli_query($con, $sql);
                
                
                $Return = "Login Posted";
                echo "{Content: \"".$Return."\"}"; 
        }

?>