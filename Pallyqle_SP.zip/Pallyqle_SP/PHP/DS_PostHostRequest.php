<?php
        
        $Return = "";
        $Hosts = $_POST["Hosts"];
        $Name = $_POST["Name"];
        $Region = $_POST["Region"];
        $MNP = $_POST["MNP"];
        $ServerType = $_REQUEST["ServerType"];
        	
	$con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");
        if ($con->connect_errno) 
        {
                $Return = "Error0";
                echo $Return; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "SELECT * FROM Servers WHERE `Name` = '".$Name."'";
                $result = mysqli_query($con, $sql);
                
                if(mysqli_num_rows($result) > 0)
                {
                        $Return = "Server Name Taken"; 
                }
                else
                {
                        $sql = "INSERT INTO `DS_HostInfo` (`Hosts`, `ServerType`, `Name`, `Password`, `Region`, `MNP`, `PG`, `IG`) 
                        VALUES ('$Hosts', '$ServerType', '$Name', 'Thienhoang1', '$Region', '$MNP', '', '')";
                        mysqli_query($con, $sql);                
                
                        $Return = "Game Posted";
                }

                echo $Return; 
	}

?>