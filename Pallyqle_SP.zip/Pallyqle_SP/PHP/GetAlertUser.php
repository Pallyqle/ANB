<?php

        $Username = S_REQUEST["Username"];

	$con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");        	
        if ($con->connect_errno) 
        {
                $Return = "Connect Failed";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$Username."'";
                $row = mysqli_fetch_assoc(mysqli_query($con, $sql));
                
                $Return = $row['Alert'];
                echo "{Content: \"".$Return."\"}";
                
                $sql = "UPDATE `Users_Play` SET `Alert` = '' WHERE `Username` = '".$row['Username']."'";
                mysqli_query($con, $sql);

        }
?>