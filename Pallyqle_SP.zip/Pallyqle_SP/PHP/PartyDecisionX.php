<?php

        $Return = "";
        $IsAccepted = "0";
        $TrueInvitor = "Pallyqle";
        $Invitors = "Pallyqle|";
        $Invitee = "Gerok";
        $IsCancel = "1";
        $NewLeader = "";
        
	//$IsAccepted = $_REQUEST["IsAccepted"];
        //$TrueInvitor = $_REQUEST["TrueInvitor"];
        //$Invitors = $_REQUEST["Invitors"];
        //$Invitee = $_REQUEST["Invitee"];
        //$IsCancel = $_REQUEST["IsCancel"];
	//$NewLeader = $_REQUEST["NewLeader"];
        
	$con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");
        if ($con->connect_errno) 
        {
                $Return = "Connect Failed";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                if($IsCancel == 0)
                {
                        $InvitorArray = explode("|", $Invitors);
                        foreach($InvitorArray as $x)
                        {
                                $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$Invitee."'";
                                $row = mysqli_fetch_assoc(mysqli_query($con, $sql));
        
                                $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$x."'";
                                $result = mysqli_query($con, $sql);
                                if(mysqli_num_rows($result) > 0)
                                {
                                        $row2 = mysqli_fetch_assoc($result);
                                        
                                        if((strpos($row['Alert'], 'Party:Decision:0:0:'.$row2['Username'].':'.$row2['CurrentChar'].':1|') === false))
                                        {
                                                //Invitors
                                                switch ($IsAccepted)
                                                {
                                                     case 0:
                                                                if((strpos($row2['Alert'], 'Party:Decision:1:1:'.$row['Username'].':'.$row['CurrentChar'].':'
                                                                        .$IsCancel. '|') !== false))
                                                                {
                                                                        $NewAlert = str_replace("Party:Decision:1:1:".$row['Username'].":".$row['CurrentChar'].":"
                                                                                .$IsCancel."|", "Party:Decision:0:1:".$row['Username'].":".$row['CurrentChar'].":"
                                                                                .$IsCancel."|", $row2['Alert']);   
                                                                        $sql = "UPDATE `Users_Play` SET `Alert` = '".$NewAlert."' WHERE `Username` = '".$row2['Username']."'";
                                                                        mysqli_query($con, $sql);
                                                                }
                                                                else if((strpos($row2['Alert'], 'Party:Decision:'.$IsAccepted.':1:'.$row['Username'].':'
                                                                        .$row['CurrentChar'].':'.$IsCancel.'|') === false))
                                                                {
                                                                        $sql = "UPDATE `Users_Play` SET `Alert` = '".$row2['Alert']."Party:Decision:"
                                                                                .$IsAccepted.":1".$row['Username'].":".$row['CurrentChar'].":".$IsCancel.
                                                                                "|' WHERE `Username` = '".$row2['Username']."'";
                                                                        mysqli_query($con, $sql);
                                                                }
                                                                break;
                                                        case 1:
                                                                if(($row2['Username'] == $TrueInvitor) && (strpos($row['Alert'], 'Party:Decision:1:1:'
                                                                        .$row2['Username'].':'.$row2['CurrentChar'].':0|') === false))
                                                                {
                                                                        if((strpos($row2['Alert'], 'Party:Decision:0:1:'.$row['Username'].':'.$row['CurrentChar'].':'
                                                                                .$IsCancel.'|') !== false))
                                                                        {
                                                                                $NewAlert = str_replace("Party:Decision:0:1:".$row['Username'].":".$row['CurrentChar']. ":".$IsCancel."|",
                                                                                                        "Party:Decision:1:1:".$row['Username'].":".$row['CurrentChar']. ":".$IsCancel."|", $row2['Alert']);   
                                                                                $sql = "UPDATE `Users_Play` SET `Alert` = '".$NewAlert."' WHERE `Username` = '".$row2['Username']."'";
                                                                                mysqli_query($con, $sql);
                                                                        }
                                                                        else if((strpos($row2['Alert'], 'Party:Decision:'.$IsAccepted.':1:'.$row['Username'].':'.$row['CurrentChar'].':'.$IsCancel.'|') === false))
                                                                        {
                                                                                $sql = "UPDATE `Users_Play` SET `Alert` = '".$row2['Alert'] . "Party:Decision:".$IsAccepted.":1".$row['Username'].":"
                                                                                        .$row['CurrentChar'].":".$IsCancel."|' WHERE `Username` = '".$row2['Username']."'";
                                                                                mysqli_query($con, $sql);
                                                                        }
                                                                }
                                                                break;   
                                                        
                                                }    
                                        }  
                                }
                        }
                }
                else
                {
                        $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$Invitee."'";
                        $row = mysqli_fetch_assoc(mysqli_query($con, $sql));
                        
                        $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$TrueInvitor."'";
                        $row2 = mysqli_fetch_assoc(mysqli_query($con, $sql));
                        
                        if((strpos($row['Alert'], 'Party:Decision:'.$IsAccepted.':0:'.$row2['Username'].':'.$row2['CurrentChar'].':' 
                                .$IsCancel.":".$NewLeader.'|') === false))
                        {
                                $sql = "UPDATE `Users_Play` SET `Alert` = '".$row['Alert']."Party:Decision:".$IsAccepted.":0:" 
                                        .$row2['Username'].":".$row2['CurrentChar'].":".$IsCancel.":".$NewLeader."|' WHERE `Username` = '".$row['Username']."'";
                                mysqli_query($con, $sql);                                
                        }   
                        
                        
                        if($NewLeader == "")
                        {
                                if((strpos($row2['Alert'], 'Party:Decision:1:1:' .$row['Username']. ':' .$row['CurrentChar']. ':0|') !== false))
                                {
                                        $NewAlert = str_replace("Party:Decision:1:1:" .$row['Username']. ":" .$row['CurrentChar']. ":0|"
                                                        , "", $row2['Alert']);   
                                        $sql = "UPDATE `Users_Play` SET `Alert` = '".$NewAlert."' WHERE `Username` = '".$row2['Username']."'";
                                        mysqli_query($con, $sql);
                                }     
                                
                                $InvitorArray = explode("|", $Invitors);
                                foreach($InvitorArray as $x)
                                {
                                        $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$x."'";
                                        $result = mysqli_query($con, $sql);
                                        
                                        if(mysqli_num_rows($result) > 0)
                                        {
                                                $row3 = mysqli_fetch_assoc($result);
                
                                                if((strpos($row3['Alert'], 'Party:Decision:0:1:'.$row['Username'].':'.$row['CurrentChar'].':0|') === false))
                                                {
                                                        $NewAlert = "Party:Decision:0:1:".$row['Username'].":".$row['CurrentChar'].":0|";   
                                                        $sql = "UPDATE `Users_Play` SET `Alert` = '".$row3['Alert'].$NewAlert."' WHERE `Username` = '".$x."'";
                                                        mysqli_query($con, $sql);
                                                }                        
                
                                        }
                                }
                        }
                        else
                        {
                                $MyNewAlert = "";
                                $NewAlert = "";    
                                
                                $AlertArray = explode("|", $row2['Alert']);
                                foreach($AlertArray as $x)
                                {
        
                                        if($x != "Party:Check" && (strpos($x, 'Party') !== false))
                                        {        
                                                $NewAlert .= $x."|";
                                        }
                                        else if($x != "")
                                        {
                                                $MyNewAlert .= $x."|";
                                        }
                                }    
                                
                                if($NewAlert != "")
                                {
                                        $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$NewLeader."'";     
                                        $row3 = mysqli_fetch_assoc(mysqli_query($con, $sql)); 
                                        
                                        $sql = "UPDATE `Users_Play` SET `Alert` = '".$row3['Alert'].$NewAlert."' WHERE `Username` = '".$NewLeader."'";
                                        mysqli_query($con, $sql);
                                }
                                
                                $sql = "UPDATE `Users_Play` SET `Alert` = '".$MyNewAlert."' WHERE `Username` = '".$TrueInvitor."'";
                                mysqli_query($con, $sql);                        
                        }               
                        
                }

        }
        
?>