<?php

        $Return = "";
        
        $PrevUsername = "";
        $PrevCharname = "";
        $IsSetCurChar = $_REQUEST["IsSetCurChar"];
        //User Info
        $UserID = $_REQUEST["UserID"];
	$Username = $_REQUEST["Username"];
        $FavServers = $_REQUEST["FavServers"];
        $CharLimit = $_REQUEST["CharLimit"];
        $FriendList = $_REQUEST["FriendList"];
        $BlockedList = $_REQUEST["BlockedList"];
        $BankInv = $_REQUEST["BankInv"];
        //Char Info
        $Server = $_REQUEST["Server"];
        $Name = $_REQUEST["Name"];
        $Class = $_REQUEST["Class"];
        $XP = $_REQUEST["XP"];
        $Status = $_REQUEST["Status"];
        $Inv = $_REQUEST["Inv"];
        $Equips = $_REQUEST["Equips"];
        $Skills = $_REQUEST["Skills"];
        $Talents = $_REQUEST["Talents"];
        $Appearance = $_REQUEST["Appearance"];
        $Gameplay = $_REQUEST["Gameplay"];
        $Keybinds = $_REQUEST["Keybinds"];
        $ChatTab = $_REQUEST["ChatTab"];
	
	$con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");
        if ($con->connect_errno) 
        {
                $Return = "Error0";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "SELECT * FROM Users_Save WHERE `UserID` = '".$UserID."'";
                $row = mysqli_fetch_assoc(mysqli_query($con, $sql));
                $PrevUsername = $row['Username'];
;                
                $sql = "UPDATE `Users_Save` SET `Username` = '".$Username."', `FavServers` = '".$FavServers."', 
                        `CharLimit` = '".$CharLimit."', `FriendList` = '".$FriendList."', `BlockedList` = '".$BlockedList."', 
                        `BankInv` = '".$BankInv."' WHERE `UserID` = '".$UserID."'";
                mysqli_query($con, $sql);
                
                $sql = "UPDATE `Users_Play` SET `Username` = '".$Username."', `CurrentChar` = '".$Name."' 
                        WHERE `Username` = '".$PrevUsername."'";
                mysqli_query($con, $sql);
                
                $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$Username."'";
                $row = mysqli_fetch_assoc(mysqli_query($con, $sql));
                $PrevCharname = $row['CurrentChar'];
                
                if($PrevCharName == "")
                {
                        $sql = "UPDATE `Users_Char` SET `Server` = '".$Server."', `Name` = '".$Name."', `Class` = '".$Class."', 
                                `XP` = '".$XP."', `Status` = '".$Status."', `Inv` = '".$Inv."', `Equips` = '".$Equips."', 
                                `Skills` = '".$Skills."', `Talents` = '".$Talents."', `Appearance` = '".$Appearance."', 
                                `Gameplay` = '".$Gameplay."', `Keybinds` = '".$Keybinds."', `ChatTab` = '".$ChatTab."' 
                                WHERE `Name` = '".$Name."'";
                }
                else
                {
                        $sql = "UPDATE `Users_Char` SET `Server` = '".$Server."', `Name` = '".$Name."', `Class` = '".$Class."', 
                                `XP` = '".$XP."', `Status` = '".$Status."', `Inv` = '".$Inv."', `Equips` = '".$Equips."', 
                                `Skills` = '".$Skills."', `Talents` = '".$Talents."', `Appearance` = '".$Appearance."', 
                                `Gameplay` = '".$Gameplay."', `Keybinds` = '".$Keybinds."', `ChatTab` = '".$ChatTab."' 
                                WHERE `PrevCharname` = '".$PrevCharname."'";
                }
                mysqli_query($con, $sql);
                        
                if($IsSetCurChar)
                {                 
                        $sql = "SELECT * FROM Users_Save WHERE `UserID` = '".$UserID."'";
                        $row = mysqli_fetch_assoc(mysqli_query($con, $sql));
                                       
                        $FriendList = explode("|", $row['FriendList']);
                        foreach($FriendList as $x)
                        {
                                $sql = "SELECT * FROM Users_Save WHERE `Username` = '".$x."'";
                                $row = mysqli_fetch_assoc(mysqli_query($con, $sql));
                                
                                $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$x."'";
                                $row2 = mysqli_fetch_assoc(mysqli_query($con, $sql));
                                
                                if($row2['IsLogin'] == 1 && (strpos($row2['Alert'], 'Friend|') === false) 
                                        && (strpos($row['FriendList'], $Username) !== false))
                                {
                                        $sql = "UPDATE `Users_Play` SET `Alert` = '".$row2['Alert']."Friend|' 
                                                WHERE `Username` = '".$x."'";
                                        mysqli_query($con, $sql);
                                        
                                }
                        }                        
                }
                
                $Return = "User Updated";
                echo "{Content: \"".$Return."\"}"; 
        }

?>