<?php
        
        $Return = "";
        $Name = $_REQUEST["Name"];
        $Password = $_REQUEST["Password"];
	
	$con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");
        if ($con->connect_errno) 
        {
                $Return = "Error0";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "UPDATE `Servers` SET `Password` = '".$Password."' WHERE `Name` = '".$Name."'";
                mysqli_query($con, $sql);
                
                $Return = "Server Password Set";
                echo "{Content: \"".$Return."\"}"; 
        }        

?>