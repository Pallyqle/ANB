<?php
        
        $Return = "";
        $ServerType = $_REQUEST["ServerType"];
	$IP = $_REQUEST["IP"];
        $Port = $_REQUEST["Port"];
        
	$con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");
        if ($con->connect_errno) 
        {
                $Return = "Connect Failed";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "SELECT * FROM DS_HostInfo";
                $result = mysqli_query($con, $sql);
                  
                if(mysqli_num_rows($result) > 0)
                {
                        $IsFirst = true;
                        while ($row = $result->fetch_assoc()) 
                        {
                                if($IsFirst == true && $row['ServerType'] == $ServerType)
                                {
                                        $sql = "UPDATE `Servers` SET `Name` = '".$row['Name']."', `Region` = '".$row['Region']."', 
                                        `MNP` = '".$row['MNP']."', `PG` = '".$row['PG']."', `IG` = '".$row['IG']."' 
                                        WHERE `IP` = '".$IP."' AND `Port` = '".$Port."'";
                                        mysqli_query($con, $sql);

                                        if($row['Password'] == "")
                                        {
                                                $Return = "Public/";
                                        }
                                        else 
                                        {
                                                $Return = "Private/";
                                        }

                                        
                                        $Return .= $row['Name']."/".$row['Password']."/".$row['Region']."/".$row['MNP']."/"
                                                .$row['PG']."/".$row['IG'];
                                                        
                                        echo "{Content: \"".$Return."\"}"; 
                                      
                                        if($ServerType == "GI")
                                        {
                                                $Hosts = explode("|", $row['Hosts']);                     
                                                foreach ($Hosts as $x) 
                                                {                                                                  
                                                        $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$x."'";
                                                        $result = mysqli_query($con, $sql);
                                                          
                                                        if(mysqli_num_rows($result) > 0)
                                                        {       
                                                               $row2 = mysqli_fetch_assoc($result);
                                                               
                                                               $sql = "UPDATE `Users_Play` SET `GIReady` = '".$IP."|".$PortNumber."' WHERE `Username` = '".$x."'";
                                                               mysqli_query($con, $sql);
                                                               
                                                               if(strpos($row2['Alert'], 'GIReady') === false)
                                                               {                                                               
                                                                       $sql = "UPDATE `Users_Play` SET `Alert` = '".$row2['Alert']."GIReady|' WHERE `Username` = '".$x."'";
                                                                       mysqli_query($con, $sql);
                                                               }                                                                           
                                                        }                      
                                                }
                                        }
                                                               
                                        $sql = "DELETE FROM DS_HostInfo WHERE `Hosts` = '".$row['Hosts']."'";
                                        mysqli_query($con, $sql);
                                        
                                        $IsFirst = false;
                                        break;
                                }
                        }
                        if($IsFirst == true)
                        {
                                $Return = "Error7";
                                echo "{Content: \"".$Return."\"}"; 
                        }
                }
                else
                {
                        $Return = "Error7";
                        echo "{Content: \"".$Return."\"}"; 
                }
        }
                
?>