<?php
        
        $Return = "";
        //$Username = "Pallyqle2";
        //$Email = "pallyqle@gmail.com";
	//$Password = "a";
        
	$Username = $_REQUEST["Username"];
        $Email = $_REQUEST["Email"];
	$Password = $_REQUEST["Password"];
	
	$con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");
        if ($con->connect_errno) 
        {
                $Return = "Error0";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "SELECT Username FROM Users_Save WHERE `Username` = '".$Username."'";
                $result = mysqli_query($con, $sql);
                if(mysqli_num_rows($result) > 0)
                {
                        $Return = "Error5";
                        echo "{Content: \"".$Return."\"}"; 
                }
                else
                {
                        $sql = "INSERT INTO `Users_Save` (`UserID`, `Username`, `Email`, `Password`, `PrevIP`, `Verification`, `PrevLogin`,
                                `FavServers`, `CharLimit`, `FriendList`, `BlockedList`, `BankInv`) 
                                VALUES (Null, '".$Username."', '".$Email."', '".$Password."', '', '', '', '', '4', '', '', '')";
                        mysqli_query($con, $sql);
                        
                        $sql = "INSERT INTO `Users_Play` (`Username`, `IsLogin`, `MainIP`, `InstanceIP`, `PotentialGI`, `Alert`, 
                                `CurrentChar`, `CurrentParty`, `Leader`, `XServerMessages`, `GIReady`) 
                                VALUES ('".$Username."', '', '', '', '', '', '', '', '', '', '')";                        
                        mysqli_query($con, $sql);    
                        
                        $Return = "User Created";    
                        echo "{Content: \"".$Return."\"}";  
                        
                }
        }

?>