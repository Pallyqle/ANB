<?php
	
        $Return = "";
        $IP = $_REQUEST["IP"];
        
	$con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");
        if ($con->connect_errno) 
        {
                $Return = "Error0";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "SELECT * FROM DS_LoginRequest WHERE `IP` = '".$IP."'";
                $result = mysqli_query($con, $sql);
                
                if(mysqli_num_rows($result) > 0)
                {
                        $row = mysqli_fetch_assoc($result);
                                                
                        $Return = $row['Username'];
                        echo "{Content: \"".$Return."\"}"; 
                        
                        $sql = "DELETE FROM DS_LoginRequest WHERE `RequestIndex` = '".$row['RequestIndex']."'";
                        mysqli_query($con, $sql);		                                        
                }
                else
                {
                        $Return = "Error13";
                        echo "{Content: \"".$Return."\"}";               
                }
        }
	
?>