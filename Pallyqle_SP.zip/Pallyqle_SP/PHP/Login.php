<?php

	$Return = "";
	//$Username = "Pallyqle";
	//$Password = "a";
	$IP = "";
        
	$Username = $_REQUEST["Username"];
	$Password = $_REQUEST["Password"];
	//$IP = $_REQUEST["IP"];
        	
	$con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");
        if ($con->connect_errno) 
        {
                $Return = "Error0";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {                
                $sql = "SELECT * FROM Users_Save WHERE `Username` = '".$Username."'";
                $result = mysqli_query($con, $sql);
                if(mysqli_num_rows($result) > 0)
                {
                
                        $row = mysqli_fetch_assoc($result);
                
                        $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$Username."'";
                        $row2 = mysqli_fetch_assoc(mysqli_query($con, $sql));
                        if($row['Password'] == $Password)
                        {
                                if($row2['IsLogin'] == 0)
                                {
                                                
                                        if($row['PrevIP'] == $IP || $row['PrevIP'] == "")
                                        {
                                                $sql = "UPDATE `Users_Save` SET `PrevIP` = '".$IP."', `PrevLogin` = ''
                                                        WHERE `Username` = '".$Username."'";
                                                mysqli_query($con, $sql); 
                                                
                                                $sql = "UPDATE `Users_Play` SET `IsLogin` = '1' WHERE `Username` = '".$Username."'";
                                                mysqli_query($con, $sql); 
                                                
                                                $Return = $row['UserID']."/".$row['Username'];
                                                echo "{Content: \"".$Return."\"}";
                                                
                                                $FriendList = explode("|", $row['FriendList']);
                                                foreach($FriendList as $x)
                                                {
                                                        $sql = "SELECT * FROM Users_Save WHERE `Username` = '".$x."'";
                                                        $row3 = mysqli_fetch_assoc(mysqli_query($con, $sql));
                                                        
                                                        $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$x."'";
                                                        $row4 = mysqli_fetch_assoc(mysqli_query($con, $sql));
                                                        
                                                        if($row4['IsLogin'] == 1 && (strpos($row4['Alert'], 'Friend|') === false) 
                                                                        && (strpos($row3['FriendList'], $Username) !== false))
                                                        {
                                                                        $sql = "UPDATE `Users_Play` SET `Alert` = '".$row4['Alert']."Friend|' 
                                                                                        WHERE `Username` = '".$x."'";
                                                                        mysqli_query($con, $sql);
                                                                        
                                                        }
                                                }
                                                if($row2['CurrentParty'] != "")
                                                {
                                                        $sql = "SELECT * FROM Users_Play 
                                                                        WHERE `CurrentParty` = '".$row2['CurrentParty']."' AND `Username` != '".$Username."'";
                                                        $result = mysqli_query($con, $sql);
                                                        if(mysqli_num_rows($result) > 0)
                                                        {
                                                                $NormalParty = str_replace("*", "", $row2['CurrentParty']);
                                                                $PartyArray = explode("|", $NormalParty);
                                                                foreach($PartyArray as $x)
                                                                {
                                                                           
                                                                        $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$x."'";
                                                                        $row5 = mysqli_fetch_assoc(mysqli_query($con, $sql));

                                                                        if($row5['IsLogin'] == 1 && $row5['Username'] != $Username && (strpos($row5['Alert'], 'Party:Check|') === false))
                                                                        {
                                                                                $sql = "UPDATE `Users_Play` SET `Alert` = '".$row5['Alert']."Party:Check|' 
                                                                                                WHERE `Username` = '".$row5['Username']."'";
                                                                                mysqli_query($con, $sql);
                                                                        }
                                                                }
                                                        }
                                                        else
                                                        {
                                                                $sql = "UPDATE `Users_Play` SET `CurrentParty` = '' WHERE `Username` = '".$Username."'";
                                                                mysqli_query($con, $sql);
                                                        }
                                                }
                                        }
                                        else
                                        {                                                
                                                $Return = "Error4";
                                                echo "{Content: \"".$Return."\"}"; 
                                        }
                                }
                                else
                                {
                                        $sql = "UPDATE `Users_Play` SET `IsLogin` = '0' WHERE `Username` = '".$Username."'";
                                        mysqli_query($con, $sql); 
                                        
                                        $Return = "Error3";
                                        echo "{Content: \"".$Return."\"}";                                 
                                }
                        }
                        else
                        {
                                $Return = "Error2";
                                echo "{Content: \"".$Return."\"}"; 
                        }						
                }
                else
                {
                       $Return = "Error1";
                       echo "{Content: \"".$Return."\"}"; 
                }
        }
	
?>