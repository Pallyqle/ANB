<?php       

        $Server = $_SERVER['REMOTE_ADDR'];           
        
        echo "{Content: \"".$Server."\"}";

?>