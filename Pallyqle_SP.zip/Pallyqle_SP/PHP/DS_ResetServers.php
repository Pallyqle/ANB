<?php
        $Return = "";
        $IsStarted = $_POST["IsStarted"];
        
        $con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");
        if ($con->connect_errno) 
        {
                $Return = "Error0";
                echo $Return; 
                exit();
                $con->close();
        }
        else
        {
                mysqli_query($con, 'TRUNCATE TABLE DS_CreationRequest');
                mysqli_query($con, 'TRUNCATE TABLE DS_HostInfo');
                mysqli_query($con, 'TRUNCATE TABLE DS_LoginRequest');
                mysqli_query($con, 'TRUNCATE TABLE Servers');
                
                $Return = "Cleared";
                echo $Return; 
        }
        
?>