<?php

        $Return = "";
	$Username = $_REQUEST["Username"];
	
	$con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");
        if ($con->connect_errno) 
        {
                $Return = "Connect Failed";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "SELECT * FROM Users WHERE `Username` = '".$Username."'";
                $row = mysqli_fetch_assoc(mysqli_query($con, $sql);
                
                $Return $row['XServerMessages'];
                echo "{Content: \"".$Return."\"}"; 
                
                $sql = "UPDATE `Users` SET `XServerMessages` = '' WHERE `Username` = '".$Username."'";
                mysqli_query($con, $sql);
        }

?>