<?php

        $Return = "";
        //$Username = "Pallyqle";
        //$CurrentParty = "";
        //$Leader = "";
        //$NewLeader = "Hundan";
        
	$Username = $_REQUEST["Username"];
        $CurrentParty = $_REQUEST["CurrentParty"];
	$NewLeader = $_REQUEST["NewLeader"];
        $Leader = $_REQUEST["Leader"];
	
	$con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");
        if ($con->connect_errno) 
        {
                $Return = "Connect Failed";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                if($Leader == $Username)
                {                                 
                        if($CurrentParty != "")
                        {
                                $PartyArray = explode("|", $CurrentParty);
                                foreach($PartyArray as $x)
                                {
                                        $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$x."'";     
                                        $row = mysqli_fetch_assoc(mysqli_query($con, $sql));                                                
                                        
                                        if($x == $Username)
                                        {
                                                $sql = "UPDATE `Users_Play` SET `CurrentParty` = '".$CurrentParty."', `Leader` = '".$Leader."' WHERE `Username` = '".$x."'";
                                                mysqli_query($con, $sql);
                                        }
                                        else
                                        {
                                                $sql = "UPDATE `Users_Play` SET `CurrentParty` = '".$CurrentParty."'
                                                        WHERE `Username` = '".$x."'";
                                                mysqli_query($con, $sql);  
                                        }
                                        if($row['IsLogin'] == 1 && (strpos($row['Alert'], 'Party:Check|') === false))
                                        {        
                                        
                                                $sql = "UPDATE `Users_Play` SET `Alert` = '".$row['Alert']."Party:Check|' WHERE `Username` = '".$x."'";
                                                mysqli_query($con, $sql);
                                        }
                                }    
                        }
                        
                }
                else if($CurrentParty == "")
                {
                        $NewAlert = "";    
                        
                        $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$Username."'";     
                        $row = mysqli_fetch_assoc(mysqli_query($con, $sql));    
                        
                        $AlertArray = explode("|", $row['Alert']);
                        foreach($AlertArray as $x)
                        {
                        
                                if($x != "" && (strpos($x, 'Party') === false))
                                {        
                                        $NewAlert .= $x . "|";
                                }
                        
                        }    
        
                        $sql = "UPDATE `Users_Play` SET `Alert` = '".$NewAlert."', `CurrentParty` = '', `Leader` = '' WHERE `Username` = '".$Username."'";
                        mysqli_query($con, $sql);        
                }
        
                //echo $CurrentParty;
        }

?>