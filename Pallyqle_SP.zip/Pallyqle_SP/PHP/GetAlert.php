<?php
        
        $Return = "";
        $FullIP = "";
        
	//$FullIP = $_REQUEST["FullIP"];
	
	$con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");        	
        if ($con->connect_errno) 
        {
                $Return = "Connect Failed";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "SELECT * FROM Users_Play WHERE `MainIP` = '".$FullIP."' OR `InstanceIP` = '".$FullIP."'";
                $result = mysqli_query($con, $sql);
                if(mysqli_num_rows($result) > 0)
                {
                        while($row = mysqli_fetch_assoc($result))
                        {
                                if($row['Alert'] != "")
                                {
                                        $Return .= $row['Username']. "/" .$row['Alert']. ";";
                                        $sql = "UPDATE `Users_Play` SET `Alert` = '' WHERE `Username` = '".$row['Username']."'";
                                        mysqli_query($con, $sql);
                                }
                        }
                        
                        echo "{Content: \"".$Return."\"}";
                }
        }
?>