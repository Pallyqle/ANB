<?php

        $Return = "";
        $Username = $_REQUEST["Username"];
	$IP = $_REQUEST["IP"];
        $PortNumber = $_REQUEST["PortNumber"];

        $con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");  
        if ($con->connect_errno) 
        {
                $Return = "Connect Failed";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "SELECT * FROM Servers WHERE `IP` = '".$IP."' AND `PortNumber` = '".$PortNumber."'";
                $result = mysqli_query($con, $sql);
                if(mysqli_num_rows($result) > 0)
                {
                        $row = mysqli_fetch_assoc($result);
                        
                        if($row['CNP'] >= $row['MNP'])
                        {
                                $Return = "Create Main Instance|" . $row['MainType'];  
                                echo "{Content: \"".$Return."\"}"; 
                        }
                        else
                        {
                                $Return = $row['IP'] . ":" . $row['PortNumber'];
                                echo "{Content: \"".$Return."\"}"; 
                        }                
                }
                else
                {
                        $sql = "SELECT * FROM Users_Save WHERE `Username` = '".$Username."'";
                        $result = mysqli_query($con, $sql);
                        if(mysqli_num_rows($result) > 0)
                        {
                                $row = mysqli_fetch_assoc($result);
                                
                                $Return = "Create Main Instance|" . $row['MainType'];    
                                echo "{Content: \"".$Return."\"}"; 
                        }
                }
        }
	
?>