<?php

        $Return = "";
        $TrueInvitor = $_REQUEST["TrueInvitor"];
        $Invitors = $_REQUEST["Invitors"];
	$Invitee = $_REQUEST["Invitee"];        
        $IsSent = $_REQUEST["IsSent"]; 
        $IsUpdateSent = $_REQUEST["IsUpdateSent"];
	
	$con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");
        if ($con->connect_errno) 
        {
                $Return = "Connect Failed";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$Invitee."'";
                $row = mysqli_fetch_assoc(mysqli_query($con, $sql));
                if($IsSent == 0)
                {
                        $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$TrueInvitor."'";
                        $row2 = mysqli_fetch_assoc(mysqli_query($con, $sql));
                        
                        $sql = "UPDATE `Users_Play` SET `Alert` = '".$row['Alert']."Party:Received:".$row2['Username']."|' 
                                WHERE `Username` = '".$row['Username']."'";
                        mysqli_query($con, $sql);
        
                }
                else 
                {
                        if($IsUpdateSent == 0)
                        {
                                $InvitorArray = explode("|", $Invitors);
                                foreach($InvitorArray as $x)
                                {
                                        $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$x."'";
                                        $row2 = mysqli_fetch_assoc(mysqli_query($con, $sql));
                                        
                                        if((strpos($row2['Alert'], 'Party:Sent:'.$row['Username'].'|') === false))
                                        {
                                                $sql = "UPDATE `Users_Play` SET `Alert` = '".$row2['Alert']."Party:Sent:".$row['Username']."|' 
                                                        WHERE `Username` = '".$row2['Username']."'";
                                                mysqli_query($con, $sql);
                                        }
                                }
                        }
                        else
                        {
                                $InvitorArray = explode("|", $Invitors);
                                foreach($InvitorArray as $x)
                                {
                                        $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$Invitee."'";
                                        $row = mysqli_fetch_assoc(mysqli_query($con, $sql));
                                        
                                        $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$x."'";
                                        $row2 = mysqli_fetch_assoc(mysqli_query($con, $sql));
                                                         
                                        if((strpos($row['Alert'], 'Party:Sent:'.$row2['Username']. '|') === false))
                                        {
                                                $sql = "UPDATE `Users_Play` SET `Alert` = '".$row['Alert']."Party:Sent:".$row2['Username']."|' 
                                                        WHERE `Username` = '".$row['Username']."'";
                                                mysqli_query($con, $sql);
                                        }
                                }
                        }
                }
        }
        
?>