<?php
	$Return = "";
        $Region = $_POST["Region"];
        
	$con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");
        if ($con->connect_errno) 
        {
                $Return = "Error0";
                echo $Return; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "SELECT * FROM DS_CreationRequest";
                $result = mysqli_query($con, $sql);
                
                if(mysqli_num_rows($result) > 0)
                {
                        while($row = mysqli_fetch_assoc($result))
                        {			
                                if($row['Region'] == $Region)
                                {
                                        $Return .= $row['MapName'] . ";";
        
                                        $sql = "DELETE FROM DS_CreationRequest WHERE `RequestIndex` = '".$row['RequestIndex']."'";
                                        mysqli_query($con, $sql);
                                }
                                echo $Return;
                        }                                          
                }
                else
                {
                        echo $Return;                
                }
        }
	
?>