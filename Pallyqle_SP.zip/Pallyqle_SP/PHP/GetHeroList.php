<?php
	
        $Return = "";
	$IsAvailable = "1";
	
	$con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");
        if ($con->connect_errno) 
        {
                $Return = "Connect Failed";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "SELECT Name FROM MOBA_HeroList WHERE `IsAvailable` = '".$IsAvailable."'";
                $result = mysqli_query($con, $sql);
                if(mysqli_num_rows($result) > 0)
                {
                        while($row = mysqli_fetch_assoc($result))
                        {			
                                $Return .= $row['Name'] . "/";
                        }
                        echo "{Content: \"".$Return."\"}"; 
                }
                else
                {
                        $Return = "No Heroes";
                        echo "{Content: \"".$Return."\"}"; 
                }
        }
        
?>