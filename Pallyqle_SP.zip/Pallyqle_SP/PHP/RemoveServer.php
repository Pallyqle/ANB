<?php

        $Return = "";
	$Name = $_REQUEST["Name"];
        
        $con = new mysqli("fdb3.awardspace.net", "2040551_rts", "Thienhoang1", "2040551_rts");   
        if ($con->connect_errno) 
        {
                $Return = "Error0";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "DELETE FROM Servers WHERE `Name` = '".$Name."'";
                mysqli_query($con, $sql);
        }
	
?>