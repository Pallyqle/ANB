// Fill out your copyright notice in the Description page of Project Settings.


#include "FL_CPP_Info.h"

FString UFL_CPP_Info::GetPortNumber(AGameModeBase* CurrentGameMode)
{
	FString PortNumber;
	PortNumber = FString::FromInt(CurrentGameMode->GetWorld()->URL.Port);
	return PortNumber;
}

void UFL_CPP_Info::ShutDown()
{
	GIsRequestingExit = true;
}