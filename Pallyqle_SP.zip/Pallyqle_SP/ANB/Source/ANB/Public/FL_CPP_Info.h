// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "Runtime/Engine/Classes/GameFramework/GameModeBase.h"
#include "FL_CPP_Info.generated.h"

/**
 * 
 */
UCLASS()
class ANB_API UFL_CPP_Info : public UBlueprintFunctionLibrary
{
	GENERATED_BODY() public:

		UFUNCTION(BlueprintPure, Category = "CPP_Info", meta = (Keywords = "Port Number"))
			static FString GetPortNumber(AGameModeBase * CurrentGameMode);
		
		UFUNCTION(BlueprintCallable, Category = "CPP_Info", meta = (HidePin = "WorldContextObject", DefaultToSelf = "WorldContextObject", Keywords = "Shut Down DS"))
			static void ShutDown();
};
